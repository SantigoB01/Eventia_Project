package com.eventia.booking.domain.exception;

public class CamposObligatoriosException extends RuntimeException {
    public CamposObligatoriosException(String message) {
        super(message);
    }
}
