package com.eventia.booking.domain.model.enums;


public enum TipoServicio {
    MUSICA,
    ARTE_CIRCENSE,
    ILUMINACION,
    TEATRO,
    ANIMACION_INFANTIL,
    SONIDO,
    DANZA,
    CATERING,
    DECORACION,
    FOTOGRAFIA_Y_VIDEO,
    SEGURIDAD,
    SERVICIOS_DE_LIMPIEZA,
    PRODUCCION_DE_EVENTOS,
    TRANSPORTE,
    MANTENIMIENTO,
    DJ,
    ANIMADOR
}
