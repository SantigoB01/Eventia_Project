package com.eventia.booking.domain.model.gateway;

public interface UsuarioGateway {
    boolean autorizacion (Long id_Usu);
}
