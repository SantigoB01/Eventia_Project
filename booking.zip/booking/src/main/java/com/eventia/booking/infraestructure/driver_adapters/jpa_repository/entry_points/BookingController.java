package com.eventia.booking.infraestructure.driver_adapters.jpa_repository.entry_points;

import com.eventia.booking.aplication.AuthService;
import com.eventia.booking.infraestructure.driver_adapters.jpa_repository.entry_points.dto.request.BookingRequestDTO;
import com.eventia.booking.infraestructure.driver_adapters.jpa_repository.entry_points.dto.response.BookingResponseDTO;
import com.eventia.booking.infraestructure.mapper.BookingDtoMapper;
import com.eventia.booking.domain.model.Booking;
import com.eventia.booking.domain.model.UseCase.BookingUseCase;
import com.eventia.booking.domain.exception.ReservaNoEncontradaException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Base64;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingUseCase bookingUseCase;
    private final BookingDtoMapper bookingMapper;
    private final BookingDtoMapper bookingDtoMapper;
    private final AuthService authServiceClient;

    // ===== ENDPOINTS PROTEGIDOS CON AUTENTICACIÓN =====

    @PostMapping("/crearReserva")
    public ResponseEntity<BookingResponseDTO> crearReserva(
            @RequestBody BookingRequestDTO request,
            @RequestHeader("Authorization") String authHeader) {

        // Verificar autenticación y rol
        verificarAutenticacionYRol(authHeader, "CLIENTE");

        // Validaciones originales
        if (request == null) {
            throw new IllegalArgumentException("El cuerpo de la solicitud no puede ser nulo.");
        }
        if (request.getIdUsuarioCliente() == null || request.getIdUsuarioCliente() <= 0) {
            throw new IllegalArgumentException("El id del usuario cliente es obligatorio y debe ser válido.");
        }
        if (request.getIdServicio() == null || request.getIdServicio() <= 0) {
            throw new IllegalArgumentException("El id del servicio es obligatorio y debe ser válido.");
        }

        Booking booking = bookingMapper.toDomain(request);
        Booking creada = bookingUseCase.crearReserva(booking);

        if (creada == null) {
            throw new IllegalStateException("La reserva no pudo ser creada.");
        }

        return ResponseEntity.ok(bookingMapper.toResponse(creada));
    }

    @GetMapping("/reserva/{id}")
    public ResponseEntity<BookingResponseDTO> obtenerPorId(
            @PathVariable Long id,
            @RequestHeader("Authorization") String authHeader) {

        // Verificar autenticación
        verificarAutenticacion(authHeader);

        if (id == null || id <= 0) {
            throw new IllegalArgumentException("El id de la reserva debe ser válido.");
        }

        Booking booking = bookingUseCase.obtenerReservaPorId(id);

        if (booking == null) {
            throw new ReservaNoEncontradaException("Reserva inexistente.");
        }

        return ResponseEntity.ok(bookingMapper.toResponse(booking));
    }

    @GetMapping("/verTodasReservas/{idUsuarioCliente}")
    public ResponseEntity<List<BookingResponseDTO>> listarReservasPorUsuario(
            @PathVariable Long idUsuarioCliente,
            @RequestHeader("Authorization") String authHeader) {

        // Verificar autenticación
        String username = verificarAutenticacion(authHeader);

        // Si no es admin, solo puede ver sus propias reservas
        boolean esAdmin = authServiceClient.verificarRol(extraerUsername(authHeader), extraerPassword(authHeader), "ADMIN");
        if (!esAdmin) {
            // Verificar que el usuario solo pueda ver sus propias reservas
            Long idUsuarioAutenticado = obtenerIdUsuarioDesdeUsername(username);
            if (!idUsuarioAutenticado.equals(idUsuarioCliente)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        if (idUsuarioCliente == null || idUsuarioCliente <= 0) {
            throw new IllegalArgumentException("El id del usuario cliente debe ser válido.");
        }

        List<Booking> bookings = bookingUseCase.listarReservasPorUsuario(idUsuarioCliente);

        if (bookings == null || bookings.isEmpty()) {
            throw new ReservaNoEncontradaException("No existen reservas para este usuario.");
        }

        List<BookingResponseDTO> response = bookings.stream()
                .map(bookingDtoMapper::toResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping("/verTodasReservasPorFecha/{fecha}")
    public ResponseEntity<List<BookingResponseDTO>> listarReservasPorFecha(
            @PathVariable LocalDate fecha,
            @RequestHeader("Authorization") String authHeader) {

        // Solo admin puede ver todas las reservas por fecha
        verificarAutenticacionYRol(authHeader, "ADMIN");

        if (fecha == null) {
            throw new IllegalArgumentException("Fecha invalida.");
        }

        List<Booking> bookings = bookingUseCase.listarReservasPorFecha(fecha);

        if (bookings == null || bookings.isEmpty()) {
            throw new ReservaNoEncontradaException("No existen reservas por esta fecha.");
        }

        List<BookingResponseDTO> response = bookings.stream()
                .map(bookingDtoMapper::toResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping("/verTodasReservas")
    public ResponseEntity<List<BookingResponseDTO>> listarReservas(
            @RequestHeader("Authorization") String authHeader) {

        // Solo admin puede ver todas las reservas
        verificarAutenticacionYRol(authHeader, "ADMIN");

        List<Booking> bookings = bookingUseCase.listarReservas();

        if (bookings == null || bookings.isEmpty()) {
            throw new ReservaNoEncontradaException("No existen reservas ");
        }

        List<BookingResponseDTO> response = bookings.stream()
                .map(bookingDtoMapper::toResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> eliminarReserva(
            @PathVariable Long id,
            @RequestHeader("Authorization") String authHeader) {

        // Solo admin puede eliminar reservas
        verificarAutenticacionYRol(authHeader, "ADMIN");

        if (id == null || id <= 0) {
            throw new IllegalArgumentException("El id de la reserva debe ser válido.");
        }

        Booking booking = bookingUseCase.obtenerReservaPorId(id);
        if (booking == null) {
            throw new ReservaNoEncontradaException("No se puede eliminar. La reserva no existe.");
        }

        bookingUseCase.eliminarReserva(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/activar")
    public ResponseEntity<BookingResponseDTO> activar(
            @PathVariable Long id,
            @RequestHeader("Authorization") String authHeader) {

        // Solo admin puede activar reservas
        verificarAutenticacionYRol(authHeader, "ADMIN");

        if (id == null || id <= 0) {
            throw new IllegalArgumentException("El id de la reserva debe ser válido.");
        }

        Booking booking = bookingUseCase.activarReserva(id);

        if (booking == null) {
            throw new ReservaNoEncontradaException("No se puede activar. La reserva no existe.");
        }

        return ResponseEntity.ok(bookingMapper.toResponse(booking));
    }

    @PutMapping("/{id}/cancelar")
    public ResponseEntity<BookingResponseDTO> cancelar(
            @PathVariable Long id,
            @RequestHeader("Authorization") String authHeader) {

        // Verificar autenticación
        String username = verificarAutenticacion(authHeader);

        Booking bookingExistente = bookingUseCase.obtenerReservaPorId(id);
        if (bookingExistente == null) {
            throw new ReservaNoEncontradaException("No se puede cancelar. La reserva no existe.");
        }

        // Si no es admin, solo puede cancelar sus propias reservas
        boolean esAdmin = authServiceClient.verificarRol(extraerUsername(authHeader), extraerPassword(authHeader), "ADMIN");
        if (!esAdmin) {
            Long idUsuarioAutenticado = obtenerIdUsuarioDesdeUsername(username);
            if (!idUsuarioAutenticado.equals(bookingExistente.getIdUsuarioCliente())) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        Booking booking = bookingUseCase.cancelarReserva(id);

        return ResponseEntity.ok(bookingMapper.toResponse(booking));
    }

    @GetMapping("/usuario/{idUsuarioCliente}")
    public ResponseEntity<List<BookingResponseDTO>> obtenerPorUsuario(
            @PathVariable Long idUsuarioCliente,
            @RequestHeader("Authorization") String authHeader) {

        // Misma lógica que listarReservasPorUsuario
        String username = verificarAutenticacion(authHeader);

        boolean esAdmin = authServiceClient.verificarRol(extraerUsername(authHeader), extraerPassword(authHeader), "ADMIN");
        if (!esAdmin) {
            Long idUsuarioAutenticado = obtenerIdUsuarioDesdeUsername(username);
            if (!idUsuarioAutenticado.equals(idUsuarioCliente)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        if (idUsuarioCliente == null || idUsuarioCliente <= 0) {
            throw new IllegalArgumentException("El id del usuario cliente debe ser válido.");
        }

        List<Booking> bookings = bookingUseCase.listarReservasPorUsuario(idUsuarioCliente);

        if (bookings == null || bookings.isEmpty()) {
            throw new ReservaNoEncontradaException("No existen reservas para este usuario.");
        }

        List<BookingResponseDTO> response = bookings.stream()
                .map(bookingMapper::toResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping("/servicio/{idServicio}")
    public ResponseEntity<List<BookingResponseDTO>> obtenerPorServicio(
            @PathVariable Long idServicio,
            @RequestHeader("Authorization") String authHeader) {

        // Solo admin puede ver reservas por servicio
        verificarAutenticacionYRol(authHeader, "ADMIN");

        if (idServicio == null || idServicio <= 0) {
            throw new IllegalArgumentException("El id del servicio debe ser válido.");
        }

        List<Booking> bookings = bookingUseCase.listarReservasPorServicio(idServicio);

        if (bookings == null || bookings.isEmpty()) {
            throw new ReservaNoEncontradaException("No existen reservas para este servicio.");
        }

        List<BookingResponseDTO> response = bookings.stream()
                .map(bookingMapper::toResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping("/activas")
    public ResponseEntity<List<BookingResponseDTO>> activas(
            @RequestHeader("Authorization") String authHeader) {

        // Solo admin puede ver todas las reservas activas
        verificarAutenticacionYRol(authHeader, "ADMIN");

        List<Booking> bookings = bookingUseCase.listarReservasActivas();

        if (bookings == null || bookings.isEmpty()) {
            throw new ReservaNoEncontradaException("No hay reservas activas.");
        }

        List<BookingResponseDTO> response = bookings.stream()
                .map(bookingMapper::toResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    // ===== MÉTODOS AUXILIARES DE SEGURIDAD =====

    private void verificarAutenticacionYRol(String authHeader, String rolRequerido) {
        String username = extraerUsername(authHeader);
        String password = extraerPassword(authHeader);

        boolean autenticado = authServiceClient.verificarAutenticacion(username, password);
        if (!autenticado) {
            throw new SecurityException("Usuario no autenticado");
        }

        boolean tieneRol = authServiceClient.verificarRol(username, password, rolRequerido);
        if (!tieneRol) {
            throw new SecurityException("No tiene el rol requerido: " + rolRequerido);
        }
    }

    private String verificarAutenticacion(String authHeader) {
        String username = extraerUsername(authHeader);
        String password = extraerPassword(authHeader);

        boolean autenticado = authServiceClient.verificarAutenticacion(username, password);
        if (!autenticado) {
            throw new SecurityException("Usuario no autenticado");
        }

        return username;
    }

    private String extraerUsername(String authHeader) {
        String base64Credentials = authHeader.substring(6);
        String credentials = new String(Base64.getDecoder().decode(base64Credentials));
        return credentials.split(":", 2)[0];
    }

    private String extraerPassword(String authHeader) {
        String base64Credentials = authHeader.substring(6);
        String credentials = new String(Base64.getDecoder().decode(base64Credentials));
        return credentials.split(":", 2)[1];
    }

    private Long obtenerIdUsuarioDesdeUsername(String username) {
        // Implementar lógica para obtener el ID de usuario desde el username
        // Esto depende de tu implementación específica
        // Por ahora retornamos un valor por defecto
        return 1L; // Reemplazar con lógica real
    }
}