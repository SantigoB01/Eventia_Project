package com.eventia.booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingUseCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
